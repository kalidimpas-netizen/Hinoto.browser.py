@echo off
python -m pip install -r requirements.txt
python -m pip install pyinstaller
pyinstaller --noconfirm --windowed --name "Hinoto.browser" Hinoto_browser.py
echo.
echo Hinoto.browser was built in the dist folder.
pause
