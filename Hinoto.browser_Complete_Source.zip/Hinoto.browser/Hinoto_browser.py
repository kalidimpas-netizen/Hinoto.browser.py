
import sys
from PyQt6.QtCore import QUrl, Qt
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import QApplication, QMainWindow, QToolBar, QLineEdit, QTabWidget, QWidget, QVBoxLayout, QMessageBox, QDialog, QListWidget, QListWidgetItem, QPushButton, QLabel
from PyQt6.QtWebEngineWidgets import QWebEngineView

APP_NAME = "Hinoto.browser"
HOME = "https://www.google.com"
YOUTUBE = "https://www.youtube.com/@loki_editsc"
SEARCH = "https://www.google.com/search?q={}"

class Tab(QWidget):
    def __init__(self, app):
        super().__init__()
        self.app = app
        self.view = QWebEngineView()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0,0,0,0)
        layout.addWidget(self.view)
        self.view.urlChanged.connect(self.url_changed)
        self.view.titleChanged.connect(self.title_changed)
        self.view.loadFinished.connect(self.loaded)

    def navigate(self, text):
        text = text.strip()
        if not text:
            return
        if "://" in text:
            url = QUrl(text)
        elif "." in text and " " not in text:
            url = QUrl("https://" + text)
        else:
            url = QUrl(SEARCH.format(QUrl.toPercentEncoding(text).data().decode()))
        self.view.setUrl(url)

    def url_changed(self, url):
        if self.app.tabs.currentWidget() is self:
            self.app.address.setText(url.toString())

    def title_changed(self, title):
        i = self.app.tabs.indexOf(self)
        if i >= 0:
            self.app.tabs.setTabText(i, (title[:20] or "New Tab") + ("…" if len(title)>20 else ""))

    def loaded(self, ok):
        if ok:
            u = self.view.url().toString()
            if u and (not self.app.history or self.app.history[-1] != u):
                self.app.history.append(u)

class Hinoto(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(1360, 850)
        self.history = []
        self.bookmarks = []
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self.sync)
        self.setCentralWidget(self.tabs)
        self.toolbar()
        self.menu()
        self.new_tab()

    def current(self):
        return self.tabs.currentWidget()

    def toolbar(self):
        bar = QToolBar("Hinoto Navigation")
        bar.setMovable(False)
        self.addToolBar(bar)

        for text, fn in [
            ("←", lambda: self.current().view.back()),
            ("→", lambda: self.current().view.forward()),
            ("⟳", lambda: self.current().view.reload()),
            ("⌂", lambda: self.current().view.setUrl(QUrl(HOME))),
        ]:
            a = QAction(text, self)
            a.triggered.connect(fn)
            bar.addAction(a)

        yt = QAction("▶ YouTube", self)
        yt.triggered.connect(lambda: self.current().view.setUrl(QUrl(YOUTUBE)))
        bar.addAction(yt)

        self.address = QLineEdit()
        self.address.setPlaceholderText("Search or enter a website...")
        self.address.returnPressed.connect(lambda: self.current().navigate(self.address.text()))
        bar.addWidget(self.address)

        go = QAction("Go", self)
        go.triggered.connect(lambda: self.current().navigate(self.address.text()))
        bar.addAction(go)

        plus = QAction("+", self)
        plus.triggered.connect(self.new_tab)
        bar.addAction(plus)

        star = QAction("☆", self)
        star.triggered.connect(self.bookmark)
        bar.addAction(star)

    def menu(self):
        filem = self.menuBar().addMenu("File")
        a = QAction("New Tab", self); a.triggered.connect(self.new_tab); filem.addAction(a)
        a = QAction("Close Tab", self); a.triggered.connect(lambda: self.close_tab(self.tabs.currentIndex())); filem.addAction(a)
        filem.addSeparator()
        a = QAction("Exit", self); a.triggered.connect(self.close); filem.addAction(a)

        tools = self.menuBar().addMenu("Tools")
        a = QAction("My YouTube Channel", self); a.triggered.connect(lambda: self.current().view.setUrl(QUrl(YOUTUBE))); tools.addAction(a)
        a = QAction("Bookmarks", self); a.triggered.connect(self.show_bookmarks); tools.addAction(a)
        a = QAction("History", self); a.triggered.connect(self.show_history); tools.addAction(a)
        a = QAction("Clear History", self); a.triggered.connect(lambda: self.history.clear()); tools.addAction(a)

        view = self.menuBar().addMenu("View")
        a = QAction("Fullscreen", self); a.setCheckable(True); a.triggered.connect(lambda checked: self.showFullScreen() if checked else self.showNormal()); view.addAction(a)

        helpm = self.menuBar().addMenu("Help")
        a = QAction("About Hinoto.browser", self); a.triggered.connect(self.about); helpm.addAction(a)

    def new_tab(self):
        t = Tab(self)
        i = self.tabs.addTab(t, "New Tab")
        self.tabs.setCurrentIndex(i)
        t.view.setUrl(QUrl(HOME))

    def close_tab(self, i):
        if self.tabs.count() == 1:
            self.new_tab()
        self.tabs.removeTab(i)

    def sync(self, i):
        if self.current():
            self.address.setText(self.current().view.url().toString())

    def bookmark(self):
        t = self.current()
        if not t: return
        pair = (t.view.title() or t.view.url().toString(), t.view.url().toString())
        if pair[1] and pair[1] not in [x[1] for x in self.bookmarks]:
            self.bookmarks.append(pair)

    def dialog_list(self, title, items):
        d = QDialog(self); d.setWindowTitle(title); d.resize(700,500)
        l = QVBoxLayout(d); w = QListWidget()
        for name, url in items:
            item = QListWidgetItem(name + "\n" + url)
            item.setData(Qt.ItemDataRole.UserRole, url)
            w.addItem(item)
        w.itemDoubleClicked.connect(lambda item: (self.current().view.setUrl(QUrl(item.data(Qt.ItemDataRole.UserRole))), d.accept()))
        l.addWidget(w)
        b = QPushButton("Close"); b.clicked.connect(d.accept); l.addWidget(b)
        d.exec()

    def show_bookmarks(self):
        self.dialog_list("Bookmarks", self.bookmarks)

    def show_history(self):
        self.dialog_list("History", [(u,u) for u in self.history])

    def about(self):
        QMessageBox.about(self, "Hinoto.browser", "Hinoto.browser 1.1\n\nCustom desktop browser with built-in L0K1 Edits YouTube shortcut.\n\nYouTube: @loki_editsc")

def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setStyle("Fusion")
    app.setStyleSheet("""
        QMainWindow { background:#0d0f13; }
        QToolBar { background:#151820; border:0; padding:7px; spacing:5px; }
        QToolButton { color:white; background:#222733; border-radius:9px; padding:8px; }
        QToolButton:hover { background:#303746; }
        QLineEdit { background:#20242d; color:white; border:1px solid #353b48; border-radius:20px; padding:10px 15px; font-size:14px; }
        QTabBar::tab { background:#181b22; color:#cdd2dc; padding:10px 18px; }
        QTabBar::tab:selected { background:#292e39; color:white; }
        QMenuBar { background:#0d0f13; color:white; }
        QMenuBar::item:selected,QMenu::item:selected { background:#303746; }
        QMenu { background:#191d25; color:white; }
    """)
    w = Hinoto()
    w.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
