# Hinoto.browser 1.1

A complete desktop browser project with a built-in shortcut to the L0K1 Edits YouTube channel.

YouTube channel:
https://www.youtube.com/@loki_editsc

## Run
Install Python 3.10+ and run:

    pip install -r requirements.txt
    python Hinoto_browser.py

## Build an executable
    pip install pyinstaller
    pyinstaller --noconfirm --windowed --name Hinoto.browser Hinoto_browser.py

The generated executable is placed in `dist/`.

## Features
- Chromium-based real web browsing
- Tabs
- Search/address bar
- Back, forward, reload, home
- Built-in YouTube channel button
- Bookmarks
- History
- Fullscreen
- Dark UI
